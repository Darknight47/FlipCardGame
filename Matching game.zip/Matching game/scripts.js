/*Card Flip*/
//Make a list of every card element and store it in the constant variabel name card.
const cards = document.querySelectorAll(".memory-card");

function flipCard() {
  /*console.log("I'm a flipCard");
    console.log(this);*/
  this.classList.toggle("flip");
}

//And then loop through all element with forEach
cards.forEach((card) => card.addEventListener("click", flipCard));
//card är ett argument vilket motsvarar varje element (img) när den loopar
//Med hjälp av addEvenetListener("click") när det är click, vi kör en funktion som heter flipCard. (execute a function)
